export default {
  theme: {
    families: {
      racing: ['"Racing Sans One"', "sans-serif"], // Define the font family
    },
    // ... other theme config
  },
};
