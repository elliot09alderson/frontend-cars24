import React, { useCallback, useEffect, useState } from "react";
import Makemodel from "../SidebarSec/Makemodel";
import ModelYear from "../SidebarSec/ModelYear";
import Fule from "../SidebarSec/Fule";
import BodyType from "../SidebarSec/BodyType";
import Color from "../SidebarSec/Color";
import Transmission from "../SidebarSec/Transmission";
import Features from "../SidebarSec/Features";
import Owners from "../SidebarSec/Owners";
import Seats from "../SidebarSec/Seats";
import Safety from "../SidebarSec/Safety";
import { useDispatch } from "react-redux";
import { filterVehicle } from "../../../../../rtk/slices/vehicleSlice.js";
import PriceRangeSlider from "../SidebarSec/MultiRangeSlider.js";
import { debounce, set } from "lodash";
const Sidebar = () => {
  const [year, setYear] = useState([2010, 2025]);
  const [kms, setKms] = useState([5000, 500000]);
  const [seat, setSeat] = useState(undefined);
  const [localValues, setLocalValues] = React.useState([100000, 4000000]);
  const dispatch = useDispatch();
  // useEffect(() => {
  //   dispatch(
  //     filterVehicle({
  //       // brand,
  //       // model,
  //       // color,
  //       minPrice: localValues[0],
  //       maxPrice: localValues[1],
  //       totalKmDriven: kms,
  //       year,
  //       // fuelType,
  //       // owners,
  //       // serialNo,
  //       // transmission,
  //       // seater,
  //     })
  //   );
  // }, [year, kms, localValues]);
  const debouncedFilter = useCallback(
    debounce((values) => {
      dispatch(
        filterVehicle({
          minPrice: values[0],
          maxPrice: values[1],
          minKmDriven: kms[0],
          maxKmDriven: kms[1],
          minYear: year[0],
          maxYear: year[1],
          seater: seat,
        })
      );
    }, 500), // 500ms delay
    [dispatch, kms, year, seat]
  );

  // Update debounced filter when slider changes
  useEffect(() => {
    debouncedFilter(localValues);
  }, [localValues, debouncedFilter]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      debouncedFilter.cancel();
    };
  }, [debouncedFilter]);
  return (
    <div className="">
      <Makemodel />
      <PriceRangeSlider
        heading="Price Range"
        min={50000}
        max={4000000}
        localValues={localValues}
        measurementText={"₹"}
        setLocalValues={setLocalValues}
      />{" "}
      <PriceRangeSlider
        max={500000}
        min={500}
        localValues={kms}
        setLocalValues={setKms}
        heading={"Kms Driven"}
        measurementText={"km"}
      />{" "}
      <PriceRangeSlider
        max={2025}
        min={2010}
        localValues={year}
        setLocalValues={setYear}
        heading={"Model Year"}
        measurementText={"year"}
      />
      {/* <ModelYear year={year} setYear={setYear} /> */}
      <Fule />
      <BodyType />
      <Color />
      <Transmission />
      <Features />
      <Owners />
      <Seats seat={seat} setSeat={setSeat} />
      <Safety />
    </div>
  );
};

export default Sidebar;
