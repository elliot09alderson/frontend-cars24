import React from "react";

const NotFound = () => {
  return (
    <div className="w-full flex items-center justify-center  h-screen bg-black text-white text-[36px] font-semibold">
      PAGE Not Found
    </div>
  );
};

export default NotFound;
