import React from "react";
import Hondacity from "./Pages/Details/Hondacity";
import { Route, Routes } from "react-router-dom";
import Home from "./Pages/Home";
import Footer from "./component_01/Footer";
import Navbar from "./component_01/Navbar";
import Postcar from "./Pages/Home/Sections/POST/Postcar";
import PostAds from "./Pages/Home/Sections/POST/PostAds";

const App = () => {
  return (
    <>
      <Navbar />

      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/detail" element={<Hondacity />} />
        <Route path="/post" element={<Postcar />} />
        <Route path="/ads" element={<PostAds />} />
      </Routes>

      <Footer />
    </>
  );
};

export default App;
