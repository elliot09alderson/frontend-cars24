import { Search } from "lucide-react";
import React, { useEffect } from "react";
import { Swiper, SwiperSlide } from "swiper/react";
import "swiper/css";
import "swiper/css/navigation";
import { Mousewheel, Keyboard, FreeMode, Navigation } from "swiper/modules";
import { useDispatch, useSelector } from "react-redux";
import { fetchAds } from "../../../../../rtk/slices/adSlice.js";
import { Link } from "react-router-dom";

const Ads = () => {
  const dispatch = useDispatch();
  useEffect(() => {
    dispatch(fetchAds());
  }, []);
  const { ads } = useSelector((slice) => slice.ad);
  return (
    <>
      <div className="lg:px-0 lg:mt-0 mt-8 px-4">
        <div className="relative bg-[#FFFFFF]   shadow rounded-xl border-b border-gray-300 ">
          <Search className="absolute size-4 lg:size-5  left-6 top-4 lg:left-4 text-[#294760]" />
          <input
            className="w-full text-xs lg:text-sm font-semibold p-4 rounded-xl  px-12"
            type="text"
            placeholder="Search for your favourite cars Previous"
          />
        </div>
      </div>
      <div className="lg:flex  px-4 lg:px-0 py-10 lg:py-12 select-none">
        <Swiper
          cssMode={true}
          mousewheel={true}
          keyboard={true}
          slidesPerView={2}
          spaceBetween={20}
          freeMode={true}
          navigation={true}
          modules={[Mousewheel, Keyboard, FreeMode, Navigation]}
          className="mySwiper"
        >
          {ads.map((item, idx) => (
            <div className=" " key={idx + "url"}>
              <SwiperSlide>
                <Link to={item.url}>
                  <img className="" src={item.image} alt="" />
                </Link>
              </SwiperSlide>
            </div>
          ))}
        </Swiper>
      </div>
    </>
  );
};

export default Ads;
