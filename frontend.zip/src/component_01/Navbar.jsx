import { ChevronDown, CircleUser, Heart } from "lucide-react";
import React from "react";
import { Link } from "react-router-dom";

const Navbar = () => {
  const financeData = [
    { text: "Buy used car", path: "" },
    { text: "Sell car", path: "/post" },
    { text: "Car finance", path: "/ads" },
    { text: "New cars", path: "" },
    { text: "Buy used car", path: "" },
    { text: "Buy used car", path: "" },
    { text: "Buy used car", path: "" },
  ];

  return (
    <div className="flex lg:px-34 px-6 shadow-md border border-b fixed z-10 bg-white border-gray-100 border-r-0 w-full lg:h-20 h-16 ">
      <div className="flex gap-2 items-center w-full  justify-between ">
        <div className="cursor-pointer">
          <img
            className="w-22 h-10 "
            src="https://media.cars24.com/cars24/seo/static/1_20230830_1693395013.png"
            alt=""
          />
        </div>
        <div className={`lg:flex lg:gap-4 gap-2 hidden cursor-pointer`}>
          {financeData.map((item, idx) => (
            <Link to={item.path}>
              <div className="flex items-center gap-2 justify-center">
                <p className="lg:text-lg text-xs text-[#0F0F26f]">
                  {item.text}
                </p>
                <ChevronDown className={`size-5 lg:flex hidden`} />
              </div>
            </Link>
          ))}
        </div>
        <div className={`flex  gap-4 items-center justify-center`}>
          <div className="flex lg:gap-4 gap-3">
            <Heart className="size-6" />
            <CircleUser className="text-black size-6" />
          </div>
          <div className="flex flex-col flex-row gap-4 cursor-pointer ">
            <div>
              <p className=""> Sign in</p>
            </div>
            <div>
              <p className=""> Log in</p>
            </div>
            <div className="flex  items-center gap-1">
              <p className="lg:text-lg lg:font-semibold ">Account </p>
              <ChevronDown className="size-5" />
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Navbar;
