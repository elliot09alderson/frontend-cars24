import { createAsyncThunk, createSlice } from "@reduxjs/toolkit";
import { api } from "../../api/api.js";

export const fetchVehicles = createAsyncThunk(
  "vehicles/fetch_vehicles",
  async (_, { rejectWithValue, fulfillWithValue }) => {
    try {
      const { data } = await api.get("/vehicles");
      return fulfillWithValue(data);
    } catch (error) {
      const errorData = error.response?.data || {
        message: "Something went wrong",
      };
      return rejectWithValue(errorData);
    }
  }
);

export const addVehicle = createAsyncThunk(
  "vehicles/add_vehicle",
  async ({values}, { rejectWithValue, fulfillWithValue }) => {
    try {
      const { data } = await api.post("/vehicle", values);
      return fulfillWithValue(data);
    } catch (error) {
      const errorData = error.response?.data || {
        message: "Something went wrong",
      };
      return rejectWithValue(errorData);
    }
  }
);
const vehicleSlice = createSlice({
  name: "vehicle",
  initialState: {
    vehicles: [],
    loading: false,
    errorMessage: "",
    successMessage: "",
  },
  reducers: {
    clearMessage: (state) => {
      (state.errorMessage = ""), (state.successMessage = "");
    },
  },

  extraReducers: (builder) => {
    builder
      .addCase(fetchVehicles.fulfilled, (state, { payload }) => {
        state.vehicles = payload.data;
        state.successMessage = payload.message;
        state.loading = false;
      })
      .addCase(fetchVehicles.pending, (state, { payload }) => {
        state.loading = true;
      })
      .addCase(fetchVehicles.rejected, (state, { payload }) => {
        state.errorMessage = payload.error;
        state.loading = false;
      })
      .addCase(addVehicle.fulfilled, (state, { payload }) => {
        state.vehicles = [...state.vehicles, payload.data];
        state.successMessage = payload.message;
        state.loading = false;
      })
      .addCase(addVehicle.pending, (state, { payload }) => {
        state.loading = true;
      })
      .addCase(addVehicle.rejected, (state, { payload }) => {
        state.errorMessage = payload.error;
        state.loading = false;
      });
  },
});
export default vehicleSlice.reducer;

export const { clearMessage } = vehicleSlice.actions;
