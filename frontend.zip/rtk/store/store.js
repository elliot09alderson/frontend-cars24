import { configureStore } from "@reduxjs/toolkit";
import vehicleSlice from "../slices/vehicleSlice.js";
import adSlice from "../slices/adSlice.js";

export const store = configureStore({
  reducer: {
    vehicle: vehicleSlice,
    ad: adSlice,
  },
});
